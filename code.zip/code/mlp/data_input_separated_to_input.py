import warnings
import pandas as pd
from pandas.core.common import SettingWithCopyWarning

pd.set_option('display.max_columns', None)
pd.set_option('display.max_rows', 100)
pd.set_option('display.width', 2000)
warnings.simplefilter(action="ignore", category=SettingWithCopyWarning)

df_data = pd.read_csv("../../data/mlp/paid/input_separated.csv")


def vectors_to_input(vectors):
    result = [[]] * len(vectors[0])
    for i in range(len(result)):
        for v in vectors:
            result[i] = result[i] + eval(v[i])
    return result


df_data["INPUT"] = vectors_to_input(
    [
        list(df_data.N_OCCURRENCES)
        , list(df_data.SEC_TIME_SPAN)
        , list(df_data.SEC_TIME_GAP)
        , list(df_data.IS_CONVERSION)
    ]
)

df_data = df_data[["ID_CUSTOMER", "INPUT"]]

print(f"\n{df_data}")

df_data.to_csv("../../data/mlp/paid/input.csv", index=False)
