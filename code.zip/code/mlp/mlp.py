import pickle
import random
import numpy as np
import pandas as pd
from tqdm import tqdm
from sklearn import metrics
from sklearn.preprocessing import StandardScaler
from sklearn.neural_network import MLPRegressor
from sklearn.model_selection import train_test_split
from sklearn.model_selection import GridSearchCV

pd.set_option('display.max_columns', None)
pd.set_option('display.max_rows', 100)
pd.set_option('display.width', 2000)


# DATA PREPROCESSING

df_input = pd.read_csv("../../data/mlp/paid/input.csv")
df_output = pd.read_csv("../../data/mlp/paid/output.csv")
mlp_input, mlp_output = [], []
for element in list(df_input.INPUT):
    mlp_input.append(eval(element))
for element in list(df_output.OUTPUT):
    mlp_output.append(eval(element))

shuffle_set = list(zip(mlp_input, mlp_output))
random.shuffle(shuffle_set)
mlp_input, mlp_output = zip(*shuffle_set)
mlp_input, mlp_output = list(mlp_input), list(mlp_output)

ss_input, ss_output = StandardScaler(), StandardScaler()
ss_input.fit(mlp_input)
ss_output.fit(mlp_output)
mlp_input_scaled, mlp_output_scaled = ss_input.transform(mlp_input), ss_output.transform(mlp_output)


# TRAIN - TEST

X_train, X_test, y_train, y_test = train_test_split(mlp_input_scaled, mlp_output_scaled, random_state=1)

print(len(mlp_input_scaled))


# PARAMETERS

parameters = {
    "learning_rate": ["constant", "invscaling", "adaptive"]
    , "solver": ["lbfgs", "sgd", "adam"]
}


# MLP

def run_model(y_test):
    regr = MLPRegressor(
        max_iter=500
        #, random_state=1
    )  #.fit(X_train, y_train)

    param_grid = {'hidden_layer_sizes': [(50, 50, 50), (100, 1)],
                  'activation': ['relu', 'tanh'],
                  'alpha': [0.0001, 0.05],
                  'learning_rate': ['constant', 'adaptive'],
                  'solver': ['adam']}

    gsc = GridSearchCV(
        regr,
        param_grid,
        cv=10, scoring=['r2', 'neg_mean_squared_error'], refit='neg_mean_squared_error', verbose=4, n_jobs=-1)

    grid_result = gsc.fit(mlp_input_scaled, mlp_output_scaled)
    best_params = grid_result.best_params_
    print(best_params)
    results = grid_result.cv_results_
    print(results)

    """predictions = regr.predict(X_test)
    y_test = ss_output.inverse_transform(y_test)
    predictions = ss_output.inverse_transform(predictions)
    y_test = postprocess_outputs(y_test)
    predictions = postprocess_outputs(predictions)
    r2_score = metrics.r2_score(y_test, predictions)
    mean_squared_log_error = metrics.mean_squared_log_error(y_test, predictions)
    return [solver, r2_score, mean_squared_log_error]"""


# DATA POSTPROCESSING

def postprocess_outputs(outputs):
    result = []
    for output in outputs:
        output = [0 if e < 0 else e for e in output]
        s = sum(output)
        output = [round(e / s, 10) for e in output]
        result.append(np.array(output))
    return np.array(result)


# RUN

run_model(y_test)


"""

# regr = MLPRegressor(random_state=1, max_iter=500, verbose=True).fit(X_train, y_train)
# pickle.dump(regr, open("../../data/mlp/models/model.sav", 'wb'))
regr = pickle.load(open("../../data/mlp/models/model.sav", 'rb'))

"""
