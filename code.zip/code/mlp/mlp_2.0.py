import numpy as np
import pandas as pd
import random as rd
from datetime import datetime
from sklearn import metrics
from sklearn.model_selection import train_test_split
from sklearn.neural_network import MLPRegressor
from sklearn.preprocessing import StandardScaler
from statistics import mean
from tqdm import tqdm


# CONFIGURATION

n_folds = 5


# --- GETTING DATA

# Getting raw data from the files
df_input = pd.read_csv("../../data/mlp/paid/input.csv")
df_output = pd.read_csv("../../data/mlp/paid/output.csv")

# Transforming row data to 2d lists
mlp_input, mlp_output = [], []
for element in list(df_input.INPUT):
    mlp_input.append(eval(element))
for element in list(df_output.OUTPUT):
    mlp_output.append(eval(element))

# Shuffling 2d input and output lists
shuffle_set = list(zip(mlp_input, mlp_output))
rd.shuffle(shuffle_set)
mlp_input, mlp_output = zip(*shuffle_set)
mlp_input, mlp_output = list(mlp_input), list(mlp_output)


# --- PREPARING DATA

# Scaling input and output lists
ss_input, ss_output = StandardScaler(), StandardScaler()
ss_input.fit(mlp_input)
ss_output.fit(mlp_output)
mlp_input_scaled, mlp_output_scaled = ss_input.transform(mlp_input), ss_output.transform(mlp_output)

# Splitting into different chunks
input_train, input_test, output_train, output_test = train_test_split(mlp_input_scaled, mlp_output_scaled, test_size=.2)

# Splitting train part into 5 folds
input_folds, output_folds = np.array_split(input_train, n_folds), np.array_split(output_train, n_folds)


# Postprocessing outputs
def postprocess_outputs(outputs, threshold):
    result = []
    for output in outputs:
        output = [0 if e < threshold else e for e in output]
        s = sum(output)
        output = [round(e / s, 10) for e in output]
        result.append(np.array(output))
    return np.array(result)


# Fitting a model
def fit_model(x_folds, y_folds, params):

    r2, mse = [], []

    for i_fold in range(n_folds):

        # Preparing data for a fold
        index_train = list(range(n_folds))
        index_train.remove(i_fold)
        x_train, x_test, y_train, y_test = [], x_folds[i_fold], [], y_folds[i_fold]
        for i_train in index_train:
            x_train.extend(x_folds[i_train])
            y_train.extend(y_folds[i_train])

        # Fitting a fold model
        model = MLPRegressor(
            max_iter=1000
            , solver=params["solver"]
            , hidden_layer_sizes=params["hidden_layer_sizes"]
            , activation=params["activation"]
            , learning_rate=params["learning_rate"]
            , alpha=params["alpha"]
        ).fit(x_train, y_train)

        # Predicting output
        y_predict = model.predict(x_test)

        # Descaling
        y_test = ss_output.inverse_transform(y_test)
        y_predict = ss_output.inverse_transform(y_predict)

        # Postprocessing
        y_test = postprocess_outputs(y_test, params["postprocessing_threshold"])
        y_predict = postprocess_outputs(y_predict, params["postprocessing_threshold"])

        # Estimating accuracy
        r2.append(metrics.r2_score(y_test, y_predict))
        mse.append(metrics.mean_squared_error(y_test, y_predict))

    return mean(r2), mean(mse)


# Parameters
option_param_solver = ["adam"]
option_param_hidden_layer_sizes = [(66, 33)]
option_param_activation = ["tanh", "tanh", "tanh", "tanh"]
option_param_learning_rate = ["adaptive"]
option_param_postprocessing_threshold = [.05]
option_param_alpha = [.0001]

print()
print("SOLVER,HIDDEN_LAYER_SIZES,ACTIVATION,LEARNING_RATE,POSTPROCESSING_THRESHOLD,ALPHA,R2,MSE,TIME")

# Grid searching
for param_solver in option_param_solver:
    for param_hidden_layer_sizes in option_param_hidden_layer_sizes:
        for param_activation in option_param_activation:
            for param_learning_rate in option_param_learning_rate:
                for param_postprocessing_threshold in option_param_postprocessing_threshold:
                    for param_alpha in option_param_alpha:

                        params = {
                            "solver": param_solver
                            , "hidden_layer_sizes": param_hidden_layer_sizes
                            , "activation": param_activation
                            , "learning_rate": param_learning_rate
                            , "postprocessing_threshold": param_postprocessing_threshold
                            , "alpha": param_alpha
                        }

                        start = datetime.now()

                        acc_r2, acc_mse = fit_model(input_folds, output_folds, params)

                        time = int((datetime.now() - start).seconds)

                        print(f"{param_solver},\"{param_hidden_layer_sizes}\",{param_activation},{param_learning_rate},{param_postprocessing_threshold},{param_alpha},{acc_r2},{acc_mse},{time}")
