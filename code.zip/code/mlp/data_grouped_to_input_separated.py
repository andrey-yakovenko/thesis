import warnings
import pandas as pd
from pandas.core.common import SettingWithCopyWarning

pd.set_option('display.max_columns', None)
pd.set_option('display.max_rows', 100)
pd.set_option('display.width', 2000)
warnings.simplefilter(action="ignore", category=SettingWithCopyWarning)

df_data = pd.read_csv("../../data/mlp/paid/grouped.csv")
print(f"\n{df_data}")

channels = sorted(df_data.CHANNEL.unique())

customers = sorted(df_data.ID_CUSTOMER.unique())
empty_column = [[]] * len(customers)

df_input = pd.DataFrame({
    "ID_CUSTOMER": customers
    , "N_OCCURRENCES": empty_column
    , "SEC_TIME_SPAN": empty_column
    , "SEC_TIME_GAP": empty_column
    , "IS_CONVERSION": empty_column
})
print(f"\n{df_input}")


def append_to_vectors(list_of_vectors, list_of_adding):
    result = []
    for i in range(len(list_of_adding)):
        result.append(list_of_vectors[i] + [list_of_adding[i]])
    return result


for channel in channels:

    df_data_channel = df_input.merge(df_data[df_data.CHANNEL == channel], on=["ID_CUSTOMER"], how="left")
    df_data_channel = df_data_channel.fillna(0)
    df_data_channel = df_data_channel.astype(
        {"OCCURRENCES": int, "TIME_SPAN": int, "TIME_GAP": int, "CONVERSION": int, }
    )

    df_data_channel["NEW_N_OCCURRENCES"] = append_to_vectors(
        list(df_data_channel.N_OCCURRENCES)
        , list(df_data_channel.OCCURRENCES)
    )
    df_data_channel["NEW_SEC_TIME_SPAN"] = append_to_vectors(
        list(df_data_channel.SEC_TIME_SPAN)
        , list(df_data_channel.TIME_SPAN)
    )
    df_data_channel["NEW_SEC_TIME_GAP"] = append_to_vectors(
        list(df_data_channel.SEC_TIME_GAP)
        , list(df_data_channel.TIME_GAP)
    )
    df_data_channel["NEW_IS_CONVERSION"] = append_to_vectors(
        list(df_data_channel.IS_CONVERSION)
        , list(df_data_channel.CONVERSION)
    )

    df_data_channel = df_data_channel[
        ["ID_CUSTOMER", "NEW_N_OCCURRENCES", "NEW_SEC_TIME_SPAN", "NEW_SEC_TIME_GAP", "NEW_IS_CONVERSION"]
    ]

    df_data_channel.rename(
        columns={
            "NEW_N_OCCURRENCES": "N_OCCURRENCES"
            , "NEW_SEC_TIME_SPAN": "SEC_TIME_SPAN"
            , "NEW_SEC_TIME_GAP": "SEC_TIME_GAP"
            , "NEW_IS_CONVERSION": "IS_CONVERSION"
        }
        , inplace=True
    )

    df_input = df_data_channel

    print(f"\n{channel} :\n\n{df_input}")

df_input.to_csv("../../data/mlp/paid/input_separated.csv", index=False)
