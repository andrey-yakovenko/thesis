import warnings
import pandas as pd
from pandas.core.common import SettingWithCopyWarning

pd.set_option('display.max_columns', None)
pd.set_option('display.max_rows', 100)
pd.set_option('display.width', 2000)
warnings.simplefilter(action="ignore", category=SettingWithCopyWarning)

df_data = pd.read_csv("../../data/raw/paid/data.csv")

print()
print(df_data)

df_data_occurrences = df_data.groupby(["ID_CUSTOMER", "CHANNEL"], as_index=False).count()
df_data_occurrences.rename(columns={df_data_occurrences.columns[2]: "OCCURRENCES"}, inplace=True)

print()
print(df_data_occurrences)

df_data_time_min = df_data.groupby(["ID_CUSTOMER", "CHANNEL"], as_index=False).min()
df_data_time_min.rename(columns={df_data_time_min.columns[2]: "TIME_MIN"}, inplace=True)

df_data_time_max = df_data.groupby(["ID_CUSTOMER", "CHANNEL"], as_index=False).max()
df_data_time_max.rename(columns={df_data_time_max.columns[2]: "TIME_MAX"}, inplace=True)

df_data_time = df_data_time_min.merge(df_data_time_max, on=["ID_CUSTOMER", "CHANNEL"], how="left")

df_data_time["TIME_SPAN"] = df_data_time.TIME_MAX - df_data_time.TIME_MIN
df_data_time_span = df_data_time[["ID_CUSTOMER", "CHANNEL", "TIME_SPAN"]]

print()
print(df_data_time_span)

df_data_time_last = df_data[["TIME_EVENT", "ID_CUSTOMER"]].groupby(["ID_CUSTOMER"], as_index=False).max()
df_data_time_last.rename(columns={df_data_time_last.columns[1]: "TIME_EVENT"}, inplace=True)

print()
print(df_data_time_last)

df_data_time_gap = df_data_time_max.merge(df_data_time_last, on=["ID_CUSTOMER"], how="left")
df_data_time_gap["TIME_GAP"] = df_data_time_gap.TIME_EVENT - df_data_time_gap.TIME_MAX
df_data_time_gap = df_data_time_gap[["ID_CUSTOMER", "CHANNEL", "TIME_GAP"]]

print()
print(df_data_time_gap)

df_data_conversion = df_data_time_last.merge(df_data, on=["ID_CUSTOMER", "TIME_EVENT"], how="left")

df_data_conversion = df_data_conversion[["ID_CUSTOMER", "CHANNEL"]].groupby(["ID_CUSTOMER"], as_index=False).max()
df_data_conversion.rename(columns={df_data_conversion.columns[1]: "CHANNEL"}, inplace=True)

df_data_conversion["CONVERSION"] = 1

print()
print(df_data_conversion)

df_data_grouped = df_data_occurrences.merge(df_data_time_span, on=["ID_CUSTOMER", "CHANNEL"], how="left")
df_data_grouped = df_data_grouped.merge(df_data_time_gap, on=["ID_CUSTOMER", "CHANNEL"], how="left")
df_data_grouped = df_data_grouped.merge(df_data_conversion, on=["ID_CUSTOMER", "CHANNEL"], how="left")
df_data_grouped = df_data_grouped.fillna(0)
df_data_grouped = df_data_grouped.astype({"CONVERSION": int})

print()
print(df_data_grouped)

print(f"\nCONV_SUM : {df_data_grouped.CONVERSION.sum()}")

df_data_grouped.to_csv("../../data/mlp/paid/grouped.csv", index=False)
