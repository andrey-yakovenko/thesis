import warnings
import pandas as pd
from pandas.core.common import SettingWithCopyWarning

pd.set_option('display.max_columns', None)
pd.set_option('display.max_rows', 100)
pd.set_option('display.width', 2000)
warnings.simplefilter(action="ignore", category=SettingWithCopyWarning)

df_channel_contribution = pd.read_csv("../../data/shap/paid/customer_channel_contribution.csv")
channels = sorted(df_channel_contribution.CHANNEL.unique())

print(f"\n{df_channel_contribution}")

customers = sorted(df_channel_contribution.ID_CUSTOMER.unique())

df_output = pd.DataFrame({
    "ID_CUSTOMER": customers
    , "OUTPUT": [[]] * len(customers)
})

print(f"\n{df_output}")


def append_to_vectors(list_of_vectors, list_of_adding):
    result = []
    for i in range(len(list_of_adding)):
        result.append(list_of_vectors[i] + [list_of_adding[i]])
    return result


for channel in channels:

    df_data_channel = df_output.merge(
        df_channel_contribution[df_channel_contribution.CHANNEL == channel]
        , on=["ID_CUSTOMER"]
        , how="left"
    )
    df_data_channel = df_data_channel.fillna(0)
    df_data_channel = df_data_channel.astype({"CONTRIBUTION": float})

    df_data_channel["NEW_OUTPUT"] = append_to_vectors(
        list(df_data_channel.OUTPUT)
        , list(df_data_channel.CONTRIBUTION)
    )

    df_data_channel = df_data_channel[["ID_CUSTOMER", "NEW_OUTPUT"]]

    df_data_channel.rename(columns={"NEW_OUTPUT": "OUTPUT"}, inplace=True)

    df_output = df_data_channel

    print(f"\n{channel} :\n\n{df_output}")

df_output.to_csv("../../data/mlp/paid/output.csv", index=False)
