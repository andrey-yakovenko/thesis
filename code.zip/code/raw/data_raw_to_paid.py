import os
import warnings
import pandas as pd
from pandas.core.common import SettingWithCopyWarning

pd.set_option('display.max_columns', None)
pd.set_option('display.max_rows', 100)
pd.set_option('display.width', 2000)
warnings.simplefilter(action="ignore", category=SettingWithCopyWarning)

df_data_raw = []
for file_path in os.listdir("../../data/raw/all"):
    df_data_raw.append(pd.read_csv(f"../../data/raw/all/{file_path}"))
df_data_raw = pd.concat(df_data_raw).reset_index(drop=True)
df_data_raw = df_data_raw[["TIME_EVENT", "ID_CUSTOMER", "CHANNEL"]]

print()
print(df_data_raw)

print(f"\nCustomers - ALL : {len(df_data_raw.ID_CUSTOMER.unique())}")

exclude_channels = ["LightBlue", "DarkMagenta", "Gray", "Purple", "Green"]

for channel in exclude_channels:
    df_data_raw = df_data_raw[df_data_raw.CHANNEL != channel]
    print(f"\nExcluding {channel} :\n")
    print(df_data_raw)

print(f"\nCustomers - PAID : {len(df_data_raw.ID_CUSTOMER.unique())}")

# df_data_raw.to_csv("../../data/raw/paid/data.csv", index=False)
