import warnings
import pandas as pd
from pandas.core.common import SettingWithCopyWarning

pd.set_option('display.max_columns', None)
pd.set_option('display.max_rows', 100)
pd.set_option('display.width', 2000)
warnings.simplefilter(action="ignore", category=SettingWithCopyWarning)

df_customer_group = pd.read_csv("../../data/shap/paid/distinct_customer_group.csv")
df_group_coalition = pd.read_csv("../../data/shap/paid/group_coalition_contribution.csv")[["COALITION", "CONTRIBUTION"]]

df_customer_group = (
    df_customer_group
    .groupby(["ID_CUSTOMER"], as_index=False)
    .apply(lambda x: ','.join(x.GROUP_LABEL))
)

df_customer_group.rename(columns={df_customer_group.columns[1]: "COALITION"}, inplace=True)

df_customer_group = (
    df_customer_group
    .merge(df_group_coalition, on=["COALITION"], how="left")
    [["ID_CUSTOMER", "CONTRIBUTION"]]
)

print(f"\n{df_customer_group}")

column_id_customer, column_group, column_contribution = [], [], []

for i in range(len(df_customer_group)):
    id_customer = df_customer_group.ID_CUSTOMER[i]
    contribution = eval(df_customer_group.CONTRIBUTION[i])
    for group in contribution.keys():
        column_id_customer.append(id_customer)
        column_group.append(group)
        column_contribution.append(float(contribution[group]))

df_customer_group = pd.DataFrame({
    "ID_CUSTOMER": column_id_customer, "GROUP": column_group, "CONTRIBUTION": column_contribution
})

print(f"\n{df_customer_group}")

df_customer_group.to_csv("../../data/shap/paid/customer_group_contribution.csv", index=False)
