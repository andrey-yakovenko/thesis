import warnings
import pandas as pd
from pandas.core.common import SettingWithCopyWarning

pd.set_option('display.max_columns', None)
pd.set_option('display.max_rows', 100)
pd.set_option('display.width', 2000)
warnings.simplefilter(action="ignore", category=SettingWithCopyWarning)

df_data = pd.read_csv("../../data/shap/paid/distinct_customer_group.csv")

df_data = (
    df_data
    .groupby(["ID_CUSTOMER"], as_index=False)
    .apply(lambda x: ','.join(x.GROUP_LABEL))
    .sort_values(["ID_CUSTOMER"])
)

df_data.rename(columns={df_data.columns[1]: "GROUP_COALITION"}, inplace=True)

df_data = (
    df_data
    .groupby(["GROUP_COALITION"], as_index=False)
    .count()
    .sort_values(["GROUP_COALITION"])
)

df_data.rename(columns={df_data.columns[1]: "CONVERSION"}, inplace=True)

print(f"\n{df_data}")

df_data.to_csv("../../data/shap/paid/group_coalition_conversion.csv", index=False)
