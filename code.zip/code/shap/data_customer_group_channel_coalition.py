import warnings
import pandas as pd
from pandas.core.common import SettingWithCopyWarning

pd.set_option('display.max_columns', None)
pd.set_option('display.max_rows', 100)
pd.set_option('display.width', 2000)
warnings.simplefilter(action="ignore", category=SettingWithCopyWarning)

df_data = pd.read_csv("../../data/raw/paid/data.csv")[["ID_CUSTOMER", "CHANNEL"]].drop_duplicates()
df_channels = pd.read_csv("../../data/meta/channels.csv")[["CHANNEL_LABEL", "GROUP_LABEL"]]

df_channels.rename(columns={"CHANNEL_LABEL": "CHANNEL", "GROUP_LABEL": "GROUP"}, inplace=True)

df_data = (
    df_data
    .merge(df_channels, on=["CHANNEL"], how="left")
    [["ID_CUSTOMER", "GROUP", "CHANNEL"]]
    .sort_values(["ID_CUSTOMER", "GROUP", "CHANNEL"])
    .groupby(["ID_CUSTOMER", "GROUP"], as_index=False)
    .apply(lambda x: ','.join(x.CHANNEL))
)

df_data.rename(columns={df_data.columns[2]: "CHANNEL_COALITION"}, inplace=True)

print(f"\n{df_data}")

df_data.to_csv("../../data/shap/paid/customer_group_channel_coalition.csv", index=False)
