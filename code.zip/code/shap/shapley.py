import warnings
import numpy as np
import pandas as pd
from pandas.core.common import SettingWithCopyWarning

pd.set_option('display.max_columns', None)
pd.set_option('display.max_rows', None)
pd.set_option('display.width', 2000)
warnings.simplefilter(action="ignore", category=SettingWithCopyWarning)

df_data = pd.read_csv("../../data/shap/paid/group_coalition_conversion.csv")

df_data.rename(columns={df_data.columns[0]: "COALITION"}, inplace=True)

df_data["COALITION_LIST"] = df_data.COALITION.apply(lambda c: c.split(","))
df_data["CARDINALITY"] = df_data.COALITION_LIST.apply(lambda l: len(l))
df_data = df_data.sort_values(["CARDINALITY"])
df_data["CONTRIBUTION"] = np.nan
degrees = df_data.CARDINALITY.unique()


def calculate_factorial(number):
    if number < 0:
        return None
    elif number == 0:
        return 1
    else:
        factorial = 1
        for x in range(1, number + 1):
            factorial *= x
        return factorial


def get_value_coalition(coalition):
    line = ""
    for channel in coalition:
        line = f"{line},{channel}"
    df_value = df_data[df_data.COALITION == line.lstrip(",")].reset_index()
    if len(df_value) == 0:
        return 0
    else:
        return df_value.CONVERSION[0]


def compute_shapley(coalition):
    value_coalition = get_value_coalition(coalition)
    contributions = {}
    total_value = 0
    for channel in coalition:
        value = 0
        subsets = [[]]
        reduced_coalition = coalition[:]
        reduced_coalition.remove(channel)
        for i in df_data[df_data.CARDINALITY < len(coalition)].index:
            is_subset = True
            for c in df_data.COALITION_LIST[i]:
                if c not in reduced_coalition:
                    is_subset = False
            if is_subset:
                subsets.append(df_data.COALITION_LIST[i])
            else:
                temp_subset = df_data.COALITION_LIST[i][:]
                temp_subset.extend(channel)
                if get_value_coalition(sorted(temp_subset)) != 0:
                    subsets.append(df_data.COALITION_LIST[i])
        for subset in subsets:
            extended_subset = subset[:]
            extended_subset.append(channel)
            addition = get_value_coalition(sorted(extended_subset)) - get_value_coalition(subset)
            addition *= calculate_factorial(len(subset)) * calculate_factorial(len(coalition)-len(subset)-1)
            # print(f"V({sorted(extended_subset)}) - V({subset}) = {get_value_coalition(sorted(extended_subset))} - {get_value_coalition(subset)}")
            # print(f"{len(subset)}! * ({len(coalition)} - {len(subset)} - 1)!")
            value += addition
            # print(sorted(extended_subset))
            # print(get_value_coalition(sorted(extended_subset)), get_value_coalition(subset))
        value /= calculate_factorial(len(coalition))
        # print(f"N! = {len(coalition)}! = {calculate_factorial(len(coalition))}")
        if value < 0:
             value = 0
        #elif value > value_coalition:
        #    value = value_coalition
        total_value += value
        contributions[channel] = value
    for key in contributions.keys():
        contributions[key] = contributions[key] / total_value

    return contributions


for i in range(len(df_data)):
    if df_data.CARDINALITY[i] == 1:
        df_data["CONTRIBUTION"][i] = {df_data.COALITION_LIST[i][0]: 1.0}
    else:
        print(df_data.COALITION_LIST[i])
        df_data["CONTRIBUTION"][i] = compute_shapley(df_data.COALITION_LIST[i])

print(df_data)

df_data.to_csv("../../data/shap/paid/group_coalition_contribution.csv", index=False)
