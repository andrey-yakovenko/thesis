import warnings
import pandas as pd
from pandas.core.common import SettingWithCopyWarning

pd.set_option('display.max_columns', None)
pd.set_option('display.max_rows', 100)
pd.set_option('display.width', 2000)
warnings.simplefilter(action="ignore", category=SettingWithCopyWarning)

df_data = pd.read_csv("../../data/raw/paid/data.csv")
df_channels = pd.read_csv("../../data/meta/channels.csv")

df_channels = df_channels[["GROUP_LABEL", "CHANNEL_LABEL"]]
df_data = (
    df_data
    [["ID_CUSTOMER", "CHANNEL"]]
    .merge(
        df_channels
        , left_on=["CHANNEL"]
        , right_on=["CHANNEL_LABEL"]
        , how="left"
    )
    [["ID_CUSTOMER", "GROUP_LABEL"]]
    .drop_duplicates()
    .sort_values(["ID_CUSTOMER", "GROUP_LABEL"])
)

print(f"\n{df_data}")

df_data.to_csv("../../data/shap/paid/distinct_customer_group.csv", index=False)
