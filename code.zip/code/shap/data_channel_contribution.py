import os
import warnings
import pandas as pd
from pandas.core.common import SettingWithCopyWarning

pd.set_option('display.max_columns', None)
pd.set_option('display.max_rows', 100)
pd.set_option('display.width', 2000)
warnings.simplefilter(action="ignore", category=SettingWithCopyWarning)

df_customer_group_channels = pd.read_csv("../../data/shap/paid/customer_group_channel_coalition.csv")
df_customer_group_contribution = pd.read_csv("../../data/shap/paid/customer_group_contribution.csv")

df_channel_coalition_contribution = []
for file_path in os.listdir("../../data/shap/paid/channel_coalition_contribution"):
    df_channel_coalition_contribution.append(
        pd.read_csv(f"../../data/shap/paid/channel_coalition_contribution/{file_path}")
    )
df_channel_coalition_contribution = pd.concat(df_channel_coalition_contribution).reset_index(drop=True)
df_channel_coalition_contribution = df_channel_coalition_contribution[["COALITION", "CONTRIBUTION"]]
df_channel_coalition_contribution.rename(
    columns={"COALITION": "CHANNEL_COALITION", "CONTRIBUTION": "CHANNEL_CONTRIBUTION"}
    , inplace=True
)

df_data = (
    df_customer_group_channels
    .merge(df_customer_group_contribution, on=["ID_CUSTOMER", "GROUP"], how="left")
    [["ID_CUSTOMER", "CHANNEL_COALITION", "CONTRIBUTION"]]
)

df_data.rename(columns={"CONTRIBUTION": "GROUP_CONTRIBUTION"}, inplace=True)

df_data = df_data[df_data.GROUP_CONTRIBUTION != 0]

df_data = df_data.merge(df_channel_coalition_contribution, on=["CHANNEL_COALITION"], how="left")

print(f"\n{df_data}")

column_id_customer, column_channel, column_contribution = [], [], []

for i in range(len(df_data)):
    id_customer = df_data.ID_CUSTOMER[i]
    group_contribution = float(df_data.GROUP_CONTRIBUTION[i])
    channel_contribution = eval(df_data.CHANNEL_CONTRIBUTION[i])
    for channel in channel_contribution.keys():
        column_id_customer.append(id_customer)
        column_channel.append(channel)
        column_contribution.append(float(channel_contribution[channel]) * group_contribution)

df_customer_channel = pd.DataFrame({
    "ID_CUSTOMER": column_id_customer, "CHANNEL": column_channel, "CONTRIBUTION": column_contribution
})

print(f"\n{df_customer_channel}")

df_customer_channel.to_csv("../../data/shap/paid/customer_channel_contribution.csv", index=False)
