import warnings
import pandas as pd
from pandas.core.common import SettingWithCopyWarning

pd.set_option('display.max_columns', None)
pd.set_option('display.max_rows', 100)
pd.set_option('display.width', 2000)
warnings.simplefilter(action="ignore", category=SettingWithCopyWarning)

df_customer_group_channels = pd.read_csv("../../data/shap/paid/customer_group_channel_coalition.csv")
df_customer_group_contribution = pd.read_csv("../../data/shap/paid/customer_group_contribution.csv")

df_data = (
    df_customer_group_channels
    .merge(df_customer_group_contribution, on=["ID_CUSTOMER", "GROUP"], how="left")
)

df_data = df_data[df_data.CONTRIBUTION != 0]

print(f"\n{df_data}")
"""
for group in df_data.GROUP.unique():

    df_channel = df_data[df_data.GROUP == group][["CHANNEL_COALITION", "CONTRIBUTION"]]
    df_channel = df_channel.groupby(["CHANNEL_COALITION"], as_index=False).sum()
    df_channel.rename(columns={df_channel.columns[1]: "CONVERSION"}, inplace=True)

    df_channel.to_csv(f"../../data/shap/paid/channel_coalition_conversion/{group.lower()}.csv", index=False)
"""
